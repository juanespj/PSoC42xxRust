/*******************************************************************************
* File Name: LchA.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LchA_ALIASES_H) /* Pins LchA_ALIASES_H */
#define CY_PINS_LchA_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define LchA_0			(LchA__0__PC)
#define LchA_0_PS		(LchA__0__PS)
#define LchA_0_PC		(LchA__0__PC)
#define LchA_0_DR		(LchA__0__DR)
#define LchA_0_SHIFT	(LchA__0__SHIFT)
#define LchA_0_INTR	((uint16)((uint16)0x0003u << (LchA__0__SHIFT*2u)))

#define LchA_INTR_ALL	 ((uint16)(LchA_0_INTR))


#endif /* End Pins LchA_ALIASES_H */


/* [] END OF FILE */
