/*******************************************************************************
* File Name: Iref.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Iref_H) /* Pins Iref_H */
#define CY_PINS_Iref_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Iref_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} Iref_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   Iref_Read(void);
void    Iref_Write(uint8 value);
uint8   Iref_ReadDataReg(void);
#if defined(Iref__PC) || (CY_PSOC4_4200L) 
    void    Iref_SetDriveMode(uint8 mode);
#endif
void    Iref_SetInterruptMode(uint16 position, uint16 mode);
uint8   Iref_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void Iref_Sleep(void); 
void Iref_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(Iref__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define Iref_DRIVE_MODE_BITS        (3)
    #define Iref_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Iref_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the Iref_SetDriveMode() function.
         *  @{
         */
        #define Iref_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define Iref_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define Iref_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define Iref_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define Iref_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define Iref_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define Iref_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define Iref_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define Iref_MASK               Iref__MASK
#define Iref_SHIFT              Iref__SHIFT
#define Iref_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Iref_SetInterruptMode() function.
     *  @{
     */
        #define Iref_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define Iref_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define Iref_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define Iref_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(Iref__SIO)
    #define Iref_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(Iref__PC) && (CY_PSOC4_4200L)
    #define Iref_USBIO_ENABLE               ((uint32)0x80000000u)
    #define Iref_USBIO_DISABLE              ((uint32)(~Iref_USBIO_ENABLE))
    #define Iref_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define Iref_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define Iref_USBIO_ENTER_SLEEP          ((uint32)((1u << Iref_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << Iref_USBIO_SUSPEND_DEL_SHIFT)))
    #define Iref_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << Iref_USBIO_SUSPEND_SHIFT)))
    #define Iref_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << Iref_USBIO_SUSPEND_DEL_SHIFT)))
    #define Iref_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(Iref__PC)
    /* Port Configuration */
    #define Iref_PC                 (* (reg32 *) Iref__PC)
#endif
/* Pin State */
#define Iref_PS                     (* (reg32 *) Iref__PS)
/* Data Register */
#define Iref_DR                     (* (reg32 *) Iref__DR)
/* Input Buffer Disable Override */
#define Iref_INP_DIS                (* (reg32 *) Iref__PC2)

/* Interrupt configuration Registers */
#define Iref_INTCFG                 (* (reg32 *) Iref__INTCFG)
#define Iref_INTSTAT                (* (reg32 *) Iref__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define Iref_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(Iref__SIO)
    #define Iref_SIO_REG            (* (reg32 *) Iref__SIO)
#endif /* (Iref__SIO_CFG) */

/* USBIO registers */
#if !defined(Iref__PC) && (CY_PSOC4_4200L)
    #define Iref_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define Iref_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define Iref_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define Iref_DRIVE_MODE_SHIFT       (0x00u)
#define Iref_DRIVE_MODE_MASK        (0x07u << Iref_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins Iref_H */


/* [] END OF FILE */
