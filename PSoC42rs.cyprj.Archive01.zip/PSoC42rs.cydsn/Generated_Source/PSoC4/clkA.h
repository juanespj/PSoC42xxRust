/*******************************************************************************
* File Name: clkA.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_clkA_H)
#define CY_CLOCK_clkA_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void clkA_StartEx(uint32 alignClkDiv);
#define clkA_Start() \
    clkA_StartEx(clkA__PA_DIV_ID)

#else

void clkA_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void clkA_Stop(void);

void clkA_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 clkA_GetDividerRegister(void);
uint8  clkA_GetFractionalDividerRegister(void);

#define clkA_Enable()                         clkA_Start()
#define clkA_Disable()                        clkA_Stop()
#define clkA_SetDividerRegister(clkDivider, reset)  \
    clkA_SetFractionalDividerRegister((clkDivider), 0u)
#define clkA_SetDivider(clkDivider)           clkA_SetDividerRegister((clkDivider), 1u)
#define clkA_SetDividerValue(clkDivider)      clkA_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define clkA_DIV_ID     clkA__DIV_ID

#define clkA_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define clkA_CTRL_REG   (*(reg32 *)clkA__CTRL_REGISTER)
#define clkA_DIV_REG    (*(reg32 *)clkA__DIV_REGISTER)

#define clkA_CMD_DIV_SHIFT          (0u)
#define clkA_CMD_PA_DIV_SHIFT       (8u)
#define clkA_CMD_DISABLE_SHIFT      (30u)
#define clkA_CMD_ENABLE_SHIFT       (31u)

#define clkA_CMD_DISABLE_MASK       ((uint32)((uint32)1u << clkA_CMD_DISABLE_SHIFT))
#define clkA_CMD_ENABLE_MASK        ((uint32)((uint32)1u << clkA_CMD_ENABLE_SHIFT))

#define clkA_DIV_FRAC_MASK  (0x000000F8u)
#define clkA_DIV_FRAC_SHIFT (3u)
#define clkA_DIV_INT_MASK   (0xFFFFFF00u)
#define clkA_DIV_INT_SHIFT  (8u)

#else 

#define clkA_DIV_REG        (*(reg32 *)clkA__REGISTER)
#define clkA_ENABLE_REG     clkA_DIV_REG
#define clkA_DIV_FRAC_MASK  clkA__FRAC_MASK
#define clkA_DIV_FRAC_SHIFT (16u)
#define clkA_DIV_INT_MASK   clkA__DIVIDER_MASK
#define clkA_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_clkA_H) */

/* [] END OF FILE */
