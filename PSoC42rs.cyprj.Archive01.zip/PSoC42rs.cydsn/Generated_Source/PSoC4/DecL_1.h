/*******************************************************************************
* File Name: DecL_1.h
* Version 2.10
*
* Description:
*  This file provides constants and parameter values for the DecL_1
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_TCPWM_DecL_1_H)
#define CY_TCPWM_DecL_1_H


#include "CyLib.h"
#include "cytypes.h"
#include "cyfitter.h"


/*******************************************************************************
* Internal Type defines
*******************************************************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} DecL_1_BACKUP_STRUCT;


/*******************************************************************************
* Variables
*******************************************************************************/
extern uint8  DecL_1_initVar;


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define DecL_1_CY_TCPWM_V2                    (CYIPBLOCK_m0s8tcpwm_VERSION == 2u)
#define DecL_1_CY_TCPWM_4000                  (CY_PSOC4_4000)

/* TCPWM Configuration */
#define DecL_1_CONFIG                         (3lu)

/* Quad Mode */
/* Parameters */
#define DecL_1_QUAD_ENCODING_MODES            (0lu)
#define DecL_1_QUAD_AUTO_START                (1lu)

/* Signal modes */
#define DecL_1_QUAD_INDEX_SIGNAL_MODE         (0lu)
#define DecL_1_QUAD_PHIA_SIGNAL_MODE          (2lu)
#define DecL_1_QUAD_PHIB_SIGNAL_MODE          (2lu)
#define DecL_1_QUAD_STOP_SIGNAL_MODE          (0lu)

/* Signal present */
#define DecL_1_QUAD_INDEX_SIGNAL_PRESENT      (0lu)
#define DecL_1_QUAD_STOP_SIGNAL_PRESENT       (0lu)

/* Interrupt Mask */
#define DecL_1_QUAD_INTERRUPT_MASK            (0lu)

/* Timer/Counter Mode */
/* Parameters */
#define DecL_1_TC_RUN_MODE                    (0lu)
#define DecL_1_TC_COUNTER_MODE                (0lu)
#define DecL_1_TC_COMP_CAP_MODE               (2lu)
#define DecL_1_TC_PRESCALER                   (0lu)

/* Signal modes */
#define DecL_1_TC_RELOAD_SIGNAL_MODE          (0lu)
#define DecL_1_TC_COUNT_SIGNAL_MODE           (3lu)
#define DecL_1_TC_START_SIGNAL_MODE           (0lu)
#define DecL_1_TC_STOP_SIGNAL_MODE            (0lu)
#define DecL_1_TC_CAPTURE_SIGNAL_MODE         (0lu)

/* Signal present */
#define DecL_1_TC_RELOAD_SIGNAL_PRESENT       (0lu)
#define DecL_1_TC_COUNT_SIGNAL_PRESENT        (0lu)
#define DecL_1_TC_START_SIGNAL_PRESENT        (0lu)
#define DecL_1_TC_STOP_SIGNAL_PRESENT         (0lu)
#define DecL_1_TC_CAPTURE_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define DecL_1_TC_INTERRUPT_MASK              (1lu)

/* PWM Mode */
/* Parameters */
#define DecL_1_PWM_KILL_EVENT                 (0lu)
#define DecL_1_PWM_STOP_EVENT                 (0lu)
#define DecL_1_PWM_MODE                       (4lu)
#define DecL_1_PWM_OUT_N_INVERT               (0lu)
#define DecL_1_PWM_OUT_INVERT                 (0lu)
#define DecL_1_PWM_ALIGN                      (0lu)
#define DecL_1_PWM_RUN_MODE                   (0lu)
#define DecL_1_PWM_DEAD_TIME_CYCLE            (0lu)
#define DecL_1_PWM_PRESCALER                  (0lu)

/* Signal modes */
#define DecL_1_PWM_RELOAD_SIGNAL_MODE         (0lu)
#define DecL_1_PWM_COUNT_SIGNAL_MODE          (3lu)
#define DecL_1_PWM_START_SIGNAL_MODE          (0lu)
#define DecL_1_PWM_STOP_SIGNAL_MODE           (0lu)
#define DecL_1_PWM_SWITCH_SIGNAL_MODE         (0lu)

/* Signal present */
#define DecL_1_PWM_RELOAD_SIGNAL_PRESENT      (0lu)
#define DecL_1_PWM_COUNT_SIGNAL_PRESENT       (0lu)
#define DecL_1_PWM_START_SIGNAL_PRESENT       (0lu)
#define DecL_1_PWM_STOP_SIGNAL_PRESENT        (0lu)
#define DecL_1_PWM_SWITCH_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define DecL_1_PWM_INTERRUPT_MASK             (1lu)


/***************************************
*    Initial Parameter Constants
***************************************/

/* Timer/Counter Mode */
#define DecL_1_TC_PERIOD_VALUE                (65535lu)
#define DecL_1_TC_COMPARE_VALUE               (65535lu)
#define DecL_1_TC_COMPARE_BUF_VALUE           (65535lu)
#define DecL_1_TC_COMPARE_SWAP                (0lu)

/* PWM Mode */
#define DecL_1_PWM_PERIOD_VALUE               (65535lu)
#define DecL_1_PWM_PERIOD_BUF_VALUE           (65535lu)
#define DecL_1_PWM_PERIOD_SWAP                (0lu)
#define DecL_1_PWM_COMPARE_VALUE              (65535lu)
#define DecL_1_PWM_COMPARE_BUF_VALUE          (65535lu)
#define DecL_1_PWM_COMPARE_SWAP               (0lu)


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define DecL_1__LEFT 0
#define DecL_1__RIGHT 1
#define DecL_1__CENTER 2
#define DecL_1__ASYMMETRIC 3

#define DecL_1__X1 0
#define DecL_1__X2 1
#define DecL_1__X4 2

#define DecL_1__PWM 4
#define DecL_1__PWM_DT 5
#define DecL_1__PWM_PR 6

#define DecL_1__INVERSE 1
#define DecL_1__DIRECT 0

#define DecL_1__CAPTURE 2
#define DecL_1__COMPARE 0

#define DecL_1__TRIG_LEVEL 3
#define DecL_1__TRIG_RISING 0
#define DecL_1__TRIG_FALLING 1
#define DecL_1__TRIG_BOTH 2

#define DecL_1__INTR_MASK_TC 1
#define DecL_1__INTR_MASK_CC_MATCH 2
#define DecL_1__INTR_MASK_NONE 0
#define DecL_1__INTR_MASK_TC_CC 3

#define DecL_1__UNCONFIG 8
#define DecL_1__TIMER 1
#define DecL_1__QUAD 3
#define DecL_1__PWM_SEL 7

#define DecL_1__COUNT_UP 0
#define DecL_1__COUNT_DOWN 1
#define DecL_1__COUNT_UPDOWN0 2
#define DecL_1__COUNT_UPDOWN1 3


/* Prescaler */
#define DecL_1_PRESCALE_DIVBY1                ((uint32)(0u << DecL_1_PRESCALER_SHIFT))
#define DecL_1_PRESCALE_DIVBY2                ((uint32)(1u << DecL_1_PRESCALER_SHIFT))
#define DecL_1_PRESCALE_DIVBY4                ((uint32)(2u << DecL_1_PRESCALER_SHIFT))
#define DecL_1_PRESCALE_DIVBY8                ((uint32)(3u << DecL_1_PRESCALER_SHIFT))
#define DecL_1_PRESCALE_DIVBY16               ((uint32)(4u << DecL_1_PRESCALER_SHIFT))
#define DecL_1_PRESCALE_DIVBY32               ((uint32)(5u << DecL_1_PRESCALER_SHIFT))
#define DecL_1_PRESCALE_DIVBY64               ((uint32)(6u << DecL_1_PRESCALER_SHIFT))
#define DecL_1_PRESCALE_DIVBY128              ((uint32)(7u << DecL_1_PRESCALER_SHIFT))

/* TCPWM set modes */
#define DecL_1_MODE_TIMER_COMPARE             ((uint32)(DecL_1__COMPARE         <<  \
                                                                  DecL_1_MODE_SHIFT))
#define DecL_1_MODE_TIMER_CAPTURE             ((uint32)(DecL_1__CAPTURE         <<  \
                                                                  DecL_1_MODE_SHIFT))
#define DecL_1_MODE_QUAD                      ((uint32)(DecL_1__QUAD            <<  \
                                                                  DecL_1_MODE_SHIFT))
#define DecL_1_MODE_PWM                       ((uint32)(DecL_1__PWM             <<  \
                                                                  DecL_1_MODE_SHIFT))
#define DecL_1_MODE_PWM_DT                    ((uint32)(DecL_1__PWM_DT          <<  \
                                                                  DecL_1_MODE_SHIFT))
#define DecL_1_MODE_PWM_PR                    ((uint32)(DecL_1__PWM_PR          <<  \
                                                                  DecL_1_MODE_SHIFT))

/* Quad Modes */
#define DecL_1_MODE_X1                        ((uint32)(DecL_1__X1              <<  \
                                                                  DecL_1_QUAD_MODE_SHIFT))
#define DecL_1_MODE_X2                        ((uint32)(DecL_1__X2              <<  \
                                                                  DecL_1_QUAD_MODE_SHIFT))
#define DecL_1_MODE_X4                        ((uint32)(DecL_1__X4              <<  \
                                                                  DecL_1_QUAD_MODE_SHIFT))

/* Counter modes */
#define DecL_1_COUNT_UP                       ((uint32)(DecL_1__COUNT_UP        <<  \
                                                                  DecL_1_UPDOWN_SHIFT))
#define DecL_1_COUNT_DOWN                     ((uint32)(DecL_1__COUNT_DOWN      <<  \
                                                                  DecL_1_UPDOWN_SHIFT))
#define DecL_1_COUNT_UPDOWN0                  ((uint32)(DecL_1__COUNT_UPDOWN0   <<  \
                                                                  DecL_1_UPDOWN_SHIFT))
#define DecL_1_COUNT_UPDOWN1                  ((uint32)(DecL_1__COUNT_UPDOWN1   <<  \
                                                                  DecL_1_UPDOWN_SHIFT))

/* PWM output invert */
#define DecL_1_INVERT_LINE                    ((uint32)(DecL_1__INVERSE         <<  \
                                                                  DecL_1_INV_OUT_SHIFT))
#define DecL_1_INVERT_LINE_N                  ((uint32)(DecL_1__INVERSE         <<  \
                                                                  DecL_1_INV_COMPL_OUT_SHIFT))

/* Trigger modes */
#define DecL_1_TRIG_RISING                    ((uint32)DecL_1__TRIG_RISING)
#define DecL_1_TRIG_FALLING                   ((uint32)DecL_1__TRIG_FALLING)
#define DecL_1_TRIG_BOTH                      ((uint32)DecL_1__TRIG_BOTH)
#define DecL_1_TRIG_LEVEL                     ((uint32)DecL_1__TRIG_LEVEL)

/* Interrupt mask */
#define DecL_1_INTR_MASK_TC                   ((uint32)DecL_1__INTR_MASK_TC)
#define DecL_1_INTR_MASK_CC_MATCH             ((uint32)DecL_1__INTR_MASK_CC_MATCH)

/* PWM Output Controls */
#define DecL_1_CC_MATCH_SET                   (0x00u)
#define DecL_1_CC_MATCH_CLEAR                 (0x01u)
#define DecL_1_CC_MATCH_INVERT                (0x02u)
#define DecL_1_CC_MATCH_NO_CHANGE             (0x03u)
#define DecL_1_OVERLOW_SET                    (0x00u)
#define DecL_1_OVERLOW_CLEAR                  (0x04u)
#define DecL_1_OVERLOW_INVERT                 (0x08u)
#define DecL_1_OVERLOW_NO_CHANGE              (0x0Cu)
#define DecL_1_UNDERFLOW_SET                  (0x00u)
#define DecL_1_UNDERFLOW_CLEAR                (0x10u)
#define DecL_1_UNDERFLOW_INVERT               (0x20u)
#define DecL_1_UNDERFLOW_NO_CHANGE            (0x30u)

/* PWM Align */
#define DecL_1_PWM_MODE_LEFT                  (DecL_1_CC_MATCH_CLEAR        |   \
                                                         DecL_1_OVERLOW_SET           |   \
                                                         DecL_1_UNDERFLOW_NO_CHANGE)
#define DecL_1_PWM_MODE_RIGHT                 (DecL_1_CC_MATCH_SET          |   \
                                                         DecL_1_OVERLOW_NO_CHANGE     |   \
                                                         DecL_1_UNDERFLOW_CLEAR)
#define DecL_1_PWM_MODE_ASYM                  (DecL_1_CC_MATCH_INVERT       |   \
                                                         DecL_1_OVERLOW_SET           |   \
                                                         DecL_1_UNDERFLOW_CLEAR)

#if (DecL_1_CY_TCPWM_V2)
    #if(DecL_1_CY_TCPWM_4000)
        #define DecL_1_PWM_MODE_CENTER                (DecL_1_CC_MATCH_INVERT       |   \
                                                                 DecL_1_OVERLOW_NO_CHANGE     |   \
                                                                 DecL_1_UNDERFLOW_CLEAR)
    #else
        #define DecL_1_PWM_MODE_CENTER                (DecL_1_CC_MATCH_INVERT       |   \
                                                                 DecL_1_OVERLOW_SET           |   \
                                                                 DecL_1_UNDERFLOW_CLEAR)
    #endif /* (DecL_1_CY_TCPWM_4000) */
#else
    #define DecL_1_PWM_MODE_CENTER                (DecL_1_CC_MATCH_INVERT       |   \
                                                             DecL_1_OVERLOW_NO_CHANGE     |   \
                                                             DecL_1_UNDERFLOW_CLEAR)
#endif /* (DecL_1_CY_TCPWM_NEW) */

/* Command operations without condition */
#define DecL_1_CMD_CAPTURE                    (0u)
#define DecL_1_CMD_RELOAD                     (8u)
#define DecL_1_CMD_STOP                       (16u)
#define DecL_1_CMD_START                      (24u)

/* Status */
#define DecL_1_STATUS_DOWN                    (1u)
#define DecL_1_STATUS_RUNNING                 (2u)


/***************************************
*        Function Prototypes
****************************************/

void   DecL_1_Init(void);
void   DecL_1_Enable(void);
void   DecL_1_Start(void);
void   DecL_1_Stop(void);

void   DecL_1_SetMode(uint32 mode);
void   DecL_1_SetCounterMode(uint32 counterMode);
void   DecL_1_SetPWMMode(uint32 modeMask);
void   DecL_1_SetQDMode(uint32 qdMode);

void   DecL_1_SetPrescaler(uint32 prescaler);
void   DecL_1_TriggerCommand(uint32 mask, uint32 command);
void   DecL_1_SetOneShot(uint32 oneShotEnable);
uint32 DecL_1_ReadStatus(void);

void   DecL_1_SetPWMSyncKill(uint32 syncKillEnable);
void   DecL_1_SetPWMStopOnKill(uint32 stopOnKillEnable);
void   DecL_1_SetPWMDeadTime(uint32 deadTime);
void   DecL_1_SetPWMInvert(uint32 mask);

void   DecL_1_SetInterruptMode(uint32 interruptMask);
uint32 DecL_1_GetInterruptSourceMasked(void);
uint32 DecL_1_GetInterruptSource(void);
void   DecL_1_ClearInterrupt(uint32 interruptMask);
void   DecL_1_SetInterrupt(uint32 interruptMask);

void   DecL_1_WriteCounter(uint32 count);
uint32 DecL_1_ReadCounter(void);

uint32 DecL_1_ReadCapture(void);
uint32 DecL_1_ReadCaptureBuf(void);

void   DecL_1_WritePeriod(uint32 period);
uint32 DecL_1_ReadPeriod(void);
void   DecL_1_WritePeriodBuf(uint32 periodBuf);
uint32 DecL_1_ReadPeriodBuf(void);

void   DecL_1_WriteCompare(uint32 compare);
uint32 DecL_1_ReadCompare(void);
void   DecL_1_WriteCompareBuf(uint32 compareBuf);
uint32 DecL_1_ReadCompareBuf(void);

void   DecL_1_SetPeriodSwap(uint32 swapEnable);
void   DecL_1_SetCompareSwap(uint32 swapEnable);

void   DecL_1_SetCaptureMode(uint32 triggerMode);
void   DecL_1_SetReloadMode(uint32 triggerMode);
void   DecL_1_SetStartMode(uint32 triggerMode);
void   DecL_1_SetStopMode(uint32 triggerMode);
void   DecL_1_SetCountMode(uint32 triggerMode);

void   DecL_1_SaveConfig(void);
void   DecL_1_RestoreConfig(void);
void   DecL_1_Sleep(void);
void   DecL_1_Wakeup(void);


/***************************************
*             Registers
***************************************/

#define DecL_1_BLOCK_CONTROL_REG              (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define DecL_1_BLOCK_CONTROL_PTR              ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define DecL_1_COMMAND_REG                    (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define DecL_1_COMMAND_PTR                    ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define DecL_1_INTRRUPT_CAUSE_REG             (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define DecL_1_INTRRUPT_CAUSE_PTR             ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define DecL_1_CONTROL_REG                    (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__CTRL )
#define DecL_1_CONTROL_PTR                    ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__CTRL )
#define DecL_1_STATUS_REG                     (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__STATUS )
#define DecL_1_STATUS_PTR                     ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__STATUS )
#define DecL_1_COUNTER_REG                    (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__COUNTER )
#define DecL_1_COUNTER_PTR                    ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__COUNTER )
#define DecL_1_COMP_CAP_REG                   (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__CC )
#define DecL_1_COMP_CAP_PTR                   ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__CC )
#define DecL_1_COMP_CAP_BUF_REG               (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__CC_BUFF )
#define DecL_1_COMP_CAP_BUF_PTR               ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__CC_BUFF )
#define DecL_1_PERIOD_REG                     (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__PERIOD )
#define DecL_1_PERIOD_PTR                     ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__PERIOD )
#define DecL_1_PERIOD_BUF_REG                 (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define DecL_1_PERIOD_BUF_PTR                 ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define DecL_1_TRIG_CONTROL0_REG              (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define DecL_1_TRIG_CONTROL0_PTR              ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define DecL_1_TRIG_CONTROL1_REG              (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define DecL_1_TRIG_CONTROL1_PTR              ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define DecL_1_TRIG_CONTROL2_REG              (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define DecL_1_TRIG_CONTROL2_PTR              ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define DecL_1_INTERRUPT_REQ_REG              (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__INTR )
#define DecL_1_INTERRUPT_REQ_PTR              ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__INTR )
#define DecL_1_INTERRUPT_SET_REG              (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__INTR_SET )
#define DecL_1_INTERRUPT_SET_PTR              ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__INTR_SET )
#define DecL_1_INTERRUPT_MASK_REG             (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__INTR_MASK )
#define DecL_1_INTERRUPT_MASK_PTR             ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__INTR_MASK )
#define DecL_1_INTERRUPT_MASKED_REG           (*(reg32 *) DecL_1_cy_m0s8_tcpwm_1__INTR_MASKED )
#define DecL_1_INTERRUPT_MASKED_PTR           ( (reg32 *) DecL_1_cy_m0s8_tcpwm_1__INTR_MASKED )


/***************************************
*       Registers Constants
***************************************/

/* Mask */
#define DecL_1_MASK                           ((uint32)DecL_1_cy_m0s8_tcpwm_1__TCPWM_CTRL_MASK)

/* Shift constants for control register */
#define DecL_1_RELOAD_CC_SHIFT                (0u)
#define DecL_1_RELOAD_PERIOD_SHIFT            (1u)
#define DecL_1_PWM_SYNC_KILL_SHIFT            (2u)
#define DecL_1_PWM_STOP_KILL_SHIFT            (3u)
#define DecL_1_PRESCALER_SHIFT                (8u)
#define DecL_1_UPDOWN_SHIFT                   (16u)
#define DecL_1_ONESHOT_SHIFT                  (18u)
#define DecL_1_QUAD_MODE_SHIFT                (20u)
#define DecL_1_INV_OUT_SHIFT                  (20u)
#define DecL_1_INV_COMPL_OUT_SHIFT            (21u)
#define DecL_1_MODE_SHIFT                     (24u)

/* Mask constants for control register */
#define DecL_1_RELOAD_CC_MASK                 ((uint32)(DecL_1_1BIT_MASK        <<  \
                                                                            DecL_1_RELOAD_CC_SHIFT))
#define DecL_1_RELOAD_PERIOD_MASK             ((uint32)(DecL_1_1BIT_MASK        <<  \
                                                                            DecL_1_RELOAD_PERIOD_SHIFT))
#define DecL_1_PWM_SYNC_KILL_MASK             ((uint32)(DecL_1_1BIT_MASK        <<  \
                                                                            DecL_1_PWM_SYNC_KILL_SHIFT))
#define DecL_1_PWM_STOP_KILL_MASK             ((uint32)(DecL_1_1BIT_MASK        <<  \
                                                                            DecL_1_PWM_STOP_KILL_SHIFT))
#define DecL_1_PRESCALER_MASK                 ((uint32)(DecL_1_8BIT_MASK        <<  \
                                                                            DecL_1_PRESCALER_SHIFT))
#define DecL_1_UPDOWN_MASK                    ((uint32)(DecL_1_2BIT_MASK        <<  \
                                                                            DecL_1_UPDOWN_SHIFT))
#define DecL_1_ONESHOT_MASK                   ((uint32)(DecL_1_1BIT_MASK        <<  \
                                                                            DecL_1_ONESHOT_SHIFT))
#define DecL_1_QUAD_MODE_MASK                 ((uint32)(DecL_1_3BIT_MASK        <<  \
                                                                            DecL_1_QUAD_MODE_SHIFT))
#define DecL_1_INV_OUT_MASK                   ((uint32)(DecL_1_2BIT_MASK        <<  \
                                                                            DecL_1_INV_OUT_SHIFT))
#define DecL_1_MODE_MASK                      ((uint32)(DecL_1_3BIT_MASK        <<  \
                                                                            DecL_1_MODE_SHIFT))

/* Shift constants for trigger control register 1 */
#define DecL_1_CAPTURE_SHIFT                  (0u)
#define DecL_1_COUNT_SHIFT                    (2u)
#define DecL_1_RELOAD_SHIFT                   (4u)
#define DecL_1_STOP_SHIFT                     (6u)
#define DecL_1_START_SHIFT                    (8u)

/* Mask constants for trigger control register 1 */
#define DecL_1_CAPTURE_MASK                   ((uint32)(DecL_1_2BIT_MASK        <<  \
                                                                  DecL_1_CAPTURE_SHIFT))
#define DecL_1_COUNT_MASK                     ((uint32)(DecL_1_2BIT_MASK        <<  \
                                                                  DecL_1_COUNT_SHIFT))
#define DecL_1_RELOAD_MASK                    ((uint32)(DecL_1_2BIT_MASK        <<  \
                                                                  DecL_1_RELOAD_SHIFT))
#define DecL_1_STOP_MASK                      ((uint32)(DecL_1_2BIT_MASK        <<  \
                                                                  DecL_1_STOP_SHIFT))
#define DecL_1_START_MASK                     ((uint32)(DecL_1_2BIT_MASK        <<  \
                                                                  DecL_1_START_SHIFT))

/* MASK */
#define DecL_1_1BIT_MASK                      ((uint32)0x01u)
#define DecL_1_2BIT_MASK                      ((uint32)0x03u)
#define DecL_1_3BIT_MASK                      ((uint32)0x07u)
#define DecL_1_6BIT_MASK                      ((uint32)0x3Fu)
#define DecL_1_8BIT_MASK                      ((uint32)0xFFu)
#define DecL_1_16BIT_MASK                     ((uint32)0xFFFFu)

/* Shift constant for status register */
#define DecL_1_RUNNING_STATUS_SHIFT           (30u)


/***************************************
*    Initial Constants
***************************************/

#define DecL_1_CTRL_QUAD_BASE_CONFIG                                                          \
        (((uint32)(DecL_1_QUAD_ENCODING_MODES     << DecL_1_QUAD_MODE_SHIFT))       |\
         ((uint32)(DecL_1_CONFIG                  << DecL_1_MODE_SHIFT)))

#define DecL_1_CTRL_PWM_BASE_CONFIG                                                           \
        (((uint32)(DecL_1_PWM_STOP_EVENT          << DecL_1_PWM_STOP_KILL_SHIFT))   |\
         ((uint32)(DecL_1_PWM_OUT_INVERT          << DecL_1_INV_OUT_SHIFT))         |\
         ((uint32)(DecL_1_PWM_OUT_N_INVERT        << DecL_1_INV_COMPL_OUT_SHIFT))   |\
         ((uint32)(DecL_1_PWM_MODE                << DecL_1_MODE_SHIFT)))

#define DecL_1_CTRL_PWM_RUN_MODE                                                              \
            ((uint32)(DecL_1_PWM_RUN_MODE         << DecL_1_ONESHOT_SHIFT))
            
#define DecL_1_CTRL_PWM_ALIGN                                                                 \
            ((uint32)(DecL_1_PWM_ALIGN            << DecL_1_UPDOWN_SHIFT))

#define DecL_1_CTRL_PWM_KILL_EVENT                                                            \
             ((uint32)(DecL_1_PWM_KILL_EVENT      << DecL_1_PWM_SYNC_KILL_SHIFT))

#define DecL_1_CTRL_PWM_DEAD_TIME_CYCLE                                                       \
            ((uint32)(DecL_1_PWM_DEAD_TIME_CYCLE  << DecL_1_PRESCALER_SHIFT))

#define DecL_1_CTRL_PWM_PRESCALER                                                             \
            ((uint32)(DecL_1_PWM_PRESCALER        << DecL_1_PRESCALER_SHIFT))

#define DecL_1_CTRL_TIMER_BASE_CONFIG                                                         \
        (((uint32)(DecL_1_TC_PRESCALER            << DecL_1_PRESCALER_SHIFT))       |\
         ((uint32)(DecL_1_TC_COUNTER_MODE         << DecL_1_UPDOWN_SHIFT))          |\
         ((uint32)(DecL_1_TC_RUN_MODE             << DecL_1_ONESHOT_SHIFT))         |\
         ((uint32)(DecL_1_TC_COMP_CAP_MODE        << DecL_1_MODE_SHIFT)))
        
#define DecL_1_QUAD_SIGNALS_MODES                                                             \
        (((uint32)(DecL_1_QUAD_PHIA_SIGNAL_MODE   << DecL_1_COUNT_SHIFT))           |\
         ((uint32)(DecL_1_QUAD_INDEX_SIGNAL_MODE  << DecL_1_RELOAD_SHIFT))          |\
         ((uint32)(DecL_1_QUAD_STOP_SIGNAL_MODE   << DecL_1_STOP_SHIFT))            |\
         ((uint32)(DecL_1_QUAD_PHIB_SIGNAL_MODE   << DecL_1_START_SHIFT)))

#define DecL_1_PWM_SIGNALS_MODES                                                              \
        (((uint32)(DecL_1_PWM_SWITCH_SIGNAL_MODE  << DecL_1_CAPTURE_SHIFT))         |\
         ((uint32)(DecL_1_PWM_COUNT_SIGNAL_MODE   << DecL_1_COUNT_SHIFT))           |\
         ((uint32)(DecL_1_PWM_RELOAD_SIGNAL_MODE  << DecL_1_RELOAD_SHIFT))          |\
         ((uint32)(DecL_1_PWM_STOP_SIGNAL_MODE    << DecL_1_STOP_SHIFT))            |\
         ((uint32)(DecL_1_PWM_START_SIGNAL_MODE   << DecL_1_START_SHIFT)))

#define DecL_1_TIMER_SIGNALS_MODES                                                            \
        (((uint32)(DecL_1_TC_CAPTURE_SIGNAL_MODE  << DecL_1_CAPTURE_SHIFT))         |\
         ((uint32)(DecL_1_TC_COUNT_SIGNAL_MODE    << DecL_1_COUNT_SHIFT))           |\
         ((uint32)(DecL_1_TC_RELOAD_SIGNAL_MODE   << DecL_1_RELOAD_SHIFT))          |\
         ((uint32)(DecL_1_TC_STOP_SIGNAL_MODE     << DecL_1_STOP_SHIFT))            |\
         ((uint32)(DecL_1_TC_START_SIGNAL_MODE    << DecL_1_START_SHIFT)))
        
#define DecL_1_TIMER_UPDOWN_CNT_USED                                                          \
                ((DecL_1__COUNT_UPDOWN0 == DecL_1_TC_COUNTER_MODE)                  ||\
                 (DecL_1__COUNT_UPDOWN1 == DecL_1_TC_COUNTER_MODE))

#define DecL_1_PWM_UPDOWN_CNT_USED                                                            \
                ((DecL_1__CENTER == DecL_1_PWM_ALIGN)                               ||\
                 (DecL_1__ASYMMETRIC == DecL_1_PWM_ALIGN))               
        
#define DecL_1_PWM_PR_INIT_VALUE              (1u)
#define DecL_1_QUAD_PERIOD_INIT_VALUE         (0x8000u)



#endif /* End CY_TCPWM_DecL_1_H */

/* [] END OF FILE */
