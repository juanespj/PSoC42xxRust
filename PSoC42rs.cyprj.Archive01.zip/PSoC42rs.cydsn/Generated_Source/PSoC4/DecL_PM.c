/*******************************************************************************
* File Name: DecL_PM.c
* Version 2.10
*
* Description:
*  This file contains the setup, control, and status commands to support
*  the component operations in the low power mode.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "DecL.h"

static DecL_BACKUP_STRUCT DecL_backup;


/*******************************************************************************
* Function Name: DecL_SaveConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to save here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SaveConfig(void)
{

}


/*******************************************************************************
* Function Name: DecL_Sleep
********************************************************************************
*
* Summary:
*  Stops the component operation and saves the user configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void DecL_Sleep(void)
{
    if(0u != (DecL_BLOCK_CONTROL_REG & DecL_MASK))
    {
        DecL_backup.enableState = 1u;
    }
    else
    {
        DecL_backup.enableState = 0u;
    }

    DecL_Stop();
    DecL_SaveConfig();
}


/*******************************************************************************
* Function Name: DecL_RestoreConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to restore here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void DecL_RestoreConfig(void)
{

}


/*******************************************************************************
* Function Name: DecL_Wakeup
********************************************************************************
*
* Summary:
*  Restores the user configuration and restores the enable state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void DecL_Wakeup(void)
{
    DecL_RestoreConfig();

    if(0u != DecL_backup.enableState)
    {
        DecL_Enable();
    }
}


/* [] END OF FILE */
