/*******************************************************************************
* File Name: LchB.c  
* Version 2.20
*
* Description:
*  This file contains APIs to set up the Pins component for low power modes.
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "LchB.h"

static LchB_BACKUP_STRUCT  LchB_backup = {0u, 0u, 0u};


/*******************************************************************************
* Function Name: LchB_Sleep
****************************************************************************//**
*
* \brief Stores the pin configuration and prepares the pin for entering chip 
*  deep-sleep/hibernate modes. This function applies only to SIO and USBIO pins.
*  It should not be called for GPIO or GPIO_OVT pins.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None 
*  
* \sideeffect
*  For SIO pins, this function configures the pin input threshold to CMOS and
*  drive level to Vddio. This is needed for SIO pins when in device 
*  deep-sleep/hibernate modes.
*
* \funcusage
*  \snippet LchB_SUT.c usage_LchB_Sleep_Wakeup
*******************************************************************************/
void LchB_Sleep(void)
{
    #if defined(LchB__PC)
        LchB_backup.pcState = LchB_PC;
    #else
        #if (CY_PSOC4_4200L)
            /* Save the regulator state and put the PHY into suspend mode */
            LchB_backup.usbState = LchB_CR1_REG;
            LchB_USB_POWER_REG |= LchB_USBIO_ENTER_SLEEP;
            LchB_CR1_REG &= LchB_USBIO_CR1_OFF;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(LchB__SIO)
        LchB_backup.sioState = LchB_SIO_REG;
        /* SIO requires unregulated output buffer and single ended input buffer */
        LchB_SIO_REG &= (uint32)(~LchB_SIO_LPM_MASK);
    #endif  
}


/*******************************************************************************
* Function Name: LchB_Wakeup
****************************************************************************//**
*
* \brief Restores the pin configuration that was saved during Pin_Sleep(). This 
* function applies only to SIO and USBIO pins. It should not be called for
* GPIO or GPIO_OVT pins.
*
* For USBIO pins, the wakeup is only triggered for falling edge interrupts.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None
*  
* \funcusage
*  Refer to LchB_Sleep() for an example usage.
*******************************************************************************/
void LchB_Wakeup(void)
{
    #if defined(LchB__PC)
        LchB_PC = LchB_backup.pcState;
    #else
        #if (CY_PSOC4_4200L)
            /* Restore the regulator state and come out of suspend mode */
            LchB_USB_POWER_REG &= LchB_USBIO_EXIT_SLEEP_PH1;
            LchB_CR1_REG = LchB_backup.usbState;
            LchB_USB_POWER_REG &= LchB_USBIO_EXIT_SLEEP_PH2;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(LchB__SIO)
        LchB_SIO_REG = LchB_backup.sioState;
    #endif
}


/* [] END OF FILE */
