/*******************************************************************************
* File Name: StepReg_PM.c
* Version 1.80
*
* Description:
*  This file contains the setup, control, and status commands to support 
*  the component operation in the low power mode. 
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "StepReg.h"

/* Check for removal by optimization */
#if !defined(StepReg_Sync_ctrl_reg__REMOVED)

static StepReg_BACKUP_STRUCT  StepReg_backup = {0u};

    
/*******************************************************************************
* Function Name: StepReg_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void StepReg_SaveConfig(void) 
{
    StepReg_backup.controlState = StepReg_Control;
}


/*******************************************************************************
* Function Name: StepReg_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*
*******************************************************************************/
void StepReg_RestoreConfig(void) 
{
     StepReg_Control = StepReg_backup.controlState;
}


/*******************************************************************************
* Function Name: StepReg_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component for entering the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void StepReg_Sleep(void) 
{
    StepReg_SaveConfig();
}


/*******************************************************************************
* Function Name: StepReg_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component after waking up from the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void StepReg_Wakeup(void)  
{
    StepReg_RestoreConfig();
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
