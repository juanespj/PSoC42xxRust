/*******************************************************************************
* File Name: LchB.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LchB_ALIASES_H) /* Pins LchB_ALIASES_H */
#define CY_PINS_LchB_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define LchB_0			(LchB__0__PC)
#define LchB_0_PS		(LchB__0__PS)
#define LchB_0_PC		(LchB__0__PC)
#define LchB_0_DR		(LchB__0__DR)
#define LchB_0_SHIFT	(LchB__0__SHIFT)
#define LchB_0_INTR	((uint16)((uint16)0x0003u << (LchB__0__SHIFT*2u)))

#define LchB_INTR_ALL	 ((uint16)(LchB_0_INTR))


#endif /* End Pins LchB_ALIASES_H */


/* [] END OF FILE */
