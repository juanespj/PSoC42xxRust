/*******************************************************************************
* File Name: Pulser_tmr_PM.c
* Version 2.10
*
* Description:
*  This file contains the setup, control, and status commands to support
*  the component operations in the low power mode.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Pulser_tmr.h"

static Pulser_tmr_BACKUP_STRUCT Pulser_tmr_backup;


/*******************************************************************************
* Function Name: Pulser_tmr_SaveConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to save here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Pulser_tmr_SaveConfig(void)
{

}


/*******************************************************************************
* Function Name: Pulser_tmr_Sleep
********************************************************************************
*
* Summary:
*  Stops the component operation and saves the user configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Pulser_tmr_Sleep(void)
{
    if(0u != (Pulser_tmr_BLOCK_CONTROL_REG & Pulser_tmr_MASK))
    {
        Pulser_tmr_backup.enableState = 1u;
    }
    else
    {
        Pulser_tmr_backup.enableState = 0u;
    }

    Pulser_tmr_Stop();
    Pulser_tmr_SaveConfig();
}


/*******************************************************************************
* Function Name: Pulser_tmr_RestoreConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to restore here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Pulser_tmr_RestoreConfig(void)
{

}


/*******************************************************************************
* Function Name: Pulser_tmr_Wakeup
********************************************************************************
*
* Summary:
*  Restores the user configuration and restores the enable state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Pulser_tmr_Wakeup(void)
{
    Pulser_tmr_RestoreConfig();

    if(0u != Pulser_tmr_backup.enableState)
    {
        Pulser_tmr_Enable();
    }
}


/* [] END OF FILE */
