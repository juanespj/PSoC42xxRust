/*******************************************************************************
* File Name: SPD_REF.c  
* Version 2.20
*
* Description:
*  This file contains APIs to set up the Pins component for low power modes.
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "SPD_REF.h"

static SPD_REF_BACKUP_STRUCT  SPD_REF_backup = {0u, 0u, 0u};


/*******************************************************************************
* Function Name: SPD_REF_Sleep
****************************************************************************//**
*
* \brief Stores the pin configuration and prepares the pin for entering chip 
*  deep-sleep/hibernate modes. This function applies only to SIO and USBIO pins.
*  It should not be called for GPIO or GPIO_OVT pins.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None 
*  
* \sideeffect
*  For SIO pins, this function configures the pin input threshold to CMOS and
*  drive level to Vddio. This is needed for SIO pins when in device 
*  deep-sleep/hibernate modes.
*
* \funcusage
*  \snippet SPD_REF_SUT.c usage_SPD_REF_Sleep_Wakeup
*******************************************************************************/
void SPD_REF_Sleep(void)
{
    #if defined(SPD_REF__PC)
        SPD_REF_backup.pcState = SPD_REF_PC;
    #else
        #if (CY_PSOC4_4200L)
            /* Save the regulator state and put the PHY into suspend mode */
            SPD_REF_backup.usbState = SPD_REF_CR1_REG;
            SPD_REF_USB_POWER_REG |= SPD_REF_USBIO_ENTER_SLEEP;
            SPD_REF_CR1_REG &= SPD_REF_USBIO_CR1_OFF;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(SPD_REF__SIO)
        SPD_REF_backup.sioState = SPD_REF_SIO_REG;
        /* SIO requires unregulated output buffer and single ended input buffer */
        SPD_REF_SIO_REG &= (uint32)(~SPD_REF_SIO_LPM_MASK);
    #endif  
}


/*******************************************************************************
* Function Name: SPD_REF_Wakeup
****************************************************************************//**
*
* \brief Restores the pin configuration that was saved during Pin_Sleep(). This 
* function applies only to SIO and USBIO pins. It should not be called for
* GPIO or GPIO_OVT pins.
*
* For USBIO pins, the wakeup is only triggered for falling edge interrupts.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None
*  
* \funcusage
*  Refer to SPD_REF_Sleep() for an example usage.
*******************************************************************************/
void SPD_REF_Wakeup(void)
{
    #if defined(SPD_REF__PC)
        SPD_REF_PC = SPD_REF_backup.pcState;
    #else
        #if (CY_PSOC4_4200L)
            /* Restore the regulator state and come out of suspend mode */
            SPD_REF_USB_POWER_REG &= SPD_REF_USBIO_EXIT_SLEEP_PH1;
            SPD_REF_CR1_REG = SPD_REF_backup.usbState;
            SPD_REF_USB_POWER_REG &= SPD_REF_USBIO_EXIT_SLEEP_PH2;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(SPD_REF__SIO)
        SPD_REF_SIO_REG = SPD_REF_backup.sioState;
    #endif
}


/* [] END OF FILE */
