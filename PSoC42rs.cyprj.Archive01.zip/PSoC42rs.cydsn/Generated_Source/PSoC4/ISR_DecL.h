/*******************************************************************************
* File Name: ISR_DecL.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_ISR_DecL_H)
#define CY_ISR_ISR_DecL_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void ISR_DecL_Start(void);
void ISR_DecL_StartEx(cyisraddress address);
void ISR_DecL_Stop(void);

CY_ISR_PROTO(ISR_DecL_Interrupt);

void ISR_DecL_SetVector(cyisraddress address);
cyisraddress ISR_DecL_GetVector(void);

void ISR_DecL_SetPriority(uint8 priority);
uint8 ISR_DecL_GetPriority(void);

void ISR_DecL_Enable(void);
uint8 ISR_DecL_GetState(void);
void ISR_DecL_Disable(void);

void ISR_DecL_SetPending(void);
void ISR_DecL_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the ISR_DecL ISR. */
#define ISR_DecL_INTC_VECTOR            ((reg32 *) ISR_DecL__INTC_VECT)

/* Address of the ISR_DecL ISR priority. */
#define ISR_DecL_INTC_PRIOR             ((reg32 *) ISR_DecL__INTC_PRIOR_REG)

/* Priority of the ISR_DecL interrupt. */
#define ISR_DecL_INTC_PRIOR_NUMBER      ISR_DecL__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable ISR_DecL interrupt. */
#define ISR_DecL_INTC_SET_EN            ((reg32 *) ISR_DecL__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the ISR_DecL interrupt. */
#define ISR_DecL_INTC_CLR_EN            ((reg32 *) ISR_DecL__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the ISR_DecL interrupt state to pending. */
#define ISR_DecL_INTC_SET_PD            ((reg32 *) ISR_DecL__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the ISR_DecL interrupt. */
#define ISR_DecL_INTC_CLR_PD            ((reg32 *) ISR_DecL__INTC_CLR_PD_REG)



#endif /* CY_ISR_ISR_DecL_H */


/* [] END OF FILE */
