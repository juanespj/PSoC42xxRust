/*******************************************************************************
* File Name: DecL.c
* Version 2.10
*
* Description:
*  This file provides the source code to the API for the DecL
*  component
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "DecL.h"

uint8 DecL_initVar = 0u;


/*******************************************************************************
* Function Name: DecL_Init
********************************************************************************
*
* Summary:
*  Initialize/Restore default DecL configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void DecL_Init(void)
{

    /* Set values from customizer to CTRL */
    #if (DecL__QUAD == DecL_CONFIG)
        DecL_CONTROL_REG = DecL_CTRL_QUAD_BASE_CONFIG;
        
        /* Set values from customizer to CTRL1 */
        DecL_TRIG_CONTROL1_REG  = DecL_QUAD_SIGNALS_MODES;

        /* Set values from customizer to INTR */
        DecL_SetInterruptMode(DecL_QUAD_INTERRUPT_MASK);
        
         /* Set other values */
        DecL_SetCounterMode(DecL_COUNT_DOWN);
        DecL_WritePeriod(DecL_QUAD_PERIOD_INIT_VALUE);
        DecL_WriteCounter(DecL_QUAD_PERIOD_INIT_VALUE);
    #endif  /* (DecL__QUAD == DecL_CONFIG) */

    #if (DecL__TIMER == DecL_CONFIG)
        DecL_CONTROL_REG = DecL_CTRL_TIMER_BASE_CONFIG;
        
        /* Set values from customizer to CTRL1 */
        DecL_TRIG_CONTROL1_REG  = DecL_TIMER_SIGNALS_MODES;
    
        /* Set values from customizer to INTR */
        DecL_SetInterruptMode(DecL_TC_INTERRUPT_MASK);
        
        /* Set other values from customizer */
        DecL_WritePeriod(DecL_TC_PERIOD_VALUE );

        #if (DecL__COMPARE == DecL_TC_COMP_CAP_MODE)
            DecL_WriteCompare(DecL_TC_COMPARE_VALUE);

            #if (1u == DecL_TC_COMPARE_SWAP)
                DecL_SetCompareSwap(1u);
                DecL_WriteCompareBuf(DecL_TC_COMPARE_BUF_VALUE);
            #endif  /* (1u == DecL_TC_COMPARE_SWAP) */
        #endif  /* (DecL__COMPARE == DecL_TC_COMP_CAP_MODE) */

        /* Initialize counter value */
        #if (DecL_CY_TCPWM_V2 && DecL_TIMER_UPDOWN_CNT_USED && !DecL_CY_TCPWM_4000)
            DecL_WriteCounter(1u);
        #elif(DecL__COUNT_DOWN == DecL_TC_COUNTER_MODE)
            DecL_WriteCounter(DecL_TC_PERIOD_VALUE);
        #else
            DecL_WriteCounter(0u);
        #endif /* (DecL_CY_TCPWM_V2 && DecL_TIMER_UPDOWN_CNT_USED && !DecL_CY_TCPWM_4000) */
    #endif  /* (DecL__TIMER == DecL_CONFIG) */

    #if (DecL__PWM_SEL == DecL_CONFIG)
        DecL_CONTROL_REG = DecL_CTRL_PWM_BASE_CONFIG;

        #if (DecL__PWM_PR == DecL_PWM_MODE)
            DecL_CONTROL_REG |= DecL_CTRL_PWM_RUN_MODE;
            DecL_WriteCounter(DecL_PWM_PR_INIT_VALUE);
        #else
            DecL_CONTROL_REG |= DecL_CTRL_PWM_ALIGN | DecL_CTRL_PWM_KILL_EVENT;
            
            /* Initialize counter value */
            #if (DecL_CY_TCPWM_V2 && DecL_PWM_UPDOWN_CNT_USED && !DecL_CY_TCPWM_4000)
                DecL_WriteCounter(1u);
            #elif (DecL__RIGHT == DecL_PWM_ALIGN)
                DecL_WriteCounter(DecL_PWM_PERIOD_VALUE);
            #else 
                DecL_WriteCounter(0u);
            #endif  /* (DecL_CY_TCPWM_V2 && DecL_PWM_UPDOWN_CNT_USED && !DecL_CY_TCPWM_4000) */
        #endif  /* (DecL__PWM_PR == DecL_PWM_MODE) */

        #if (DecL__PWM_DT == DecL_PWM_MODE)
            DecL_CONTROL_REG |= DecL_CTRL_PWM_DEAD_TIME_CYCLE;
        #endif  /* (DecL__PWM_DT == DecL_PWM_MODE) */

        #if (DecL__PWM == DecL_PWM_MODE)
            DecL_CONTROL_REG |= DecL_CTRL_PWM_PRESCALER;
        #endif  /* (DecL__PWM == DecL_PWM_MODE) */

        /* Set values from customizer to CTRL1 */
        DecL_TRIG_CONTROL1_REG  = DecL_PWM_SIGNALS_MODES;
    
        /* Set values from customizer to INTR */
        DecL_SetInterruptMode(DecL_PWM_INTERRUPT_MASK);

        /* Set values from customizer to CTRL2 */
        #if (DecL__PWM_PR == DecL_PWM_MODE)
            DecL_TRIG_CONTROL2_REG =
                    (DecL_CC_MATCH_NO_CHANGE    |
                    DecL_OVERLOW_NO_CHANGE      |
                    DecL_UNDERFLOW_NO_CHANGE);
        #else
            #if (DecL__LEFT == DecL_PWM_ALIGN)
                DecL_TRIG_CONTROL2_REG = DecL_PWM_MODE_LEFT;
            #endif  /* ( DecL_PWM_LEFT == DecL_PWM_ALIGN) */

            #if (DecL__RIGHT == DecL_PWM_ALIGN)
                DecL_TRIG_CONTROL2_REG = DecL_PWM_MODE_RIGHT;
            #endif  /* ( DecL_PWM_RIGHT == DecL_PWM_ALIGN) */

            #if (DecL__CENTER == DecL_PWM_ALIGN)
                DecL_TRIG_CONTROL2_REG = DecL_PWM_MODE_CENTER;
            #endif  /* ( DecL_PWM_CENTER == DecL_PWM_ALIGN) */

            #if (DecL__ASYMMETRIC == DecL_PWM_ALIGN)
                DecL_TRIG_CONTROL2_REG = DecL_PWM_MODE_ASYM;
            #endif  /* (DecL__ASYMMETRIC == DecL_PWM_ALIGN) */
        #endif  /* (DecL__PWM_PR == DecL_PWM_MODE) */

        /* Set other values from customizer */
        DecL_WritePeriod(DecL_PWM_PERIOD_VALUE );
        DecL_WriteCompare(DecL_PWM_COMPARE_VALUE);

        #if (1u == DecL_PWM_COMPARE_SWAP)
            DecL_SetCompareSwap(1u);
            DecL_WriteCompareBuf(DecL_PWM_COMPARE_BUF_VALUE);
        #endif  /* (1u == DecL_PWM_COMPARE_SWAP) */

        #if (1u == DecL_PWM_PERIOD_SWAP)
            DecL_SetPeriodSwap(1u);
            DecL_WritePeriodBuf(DecL_PWM_PERIOD_BUF_VALUE);
        #endif  /* (1u == DecL_PWM_PERIOD_SWAP) */
    #endif  /* (DecL__PWM_SEL == DecL_CONFIG) */
    
}


/*******************************************************************************
* Function Name: DecL_Enable
********************************************************************************
*
* Summary:
*  Enables the DecL.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void DecL_Enable(void)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();
    DecL_BLOCK_CONTROL_REG |= DecL_MASK;
    CyExitCriticalSection(enableInterrupts);

    /* Start Timer or PWM if start input is absent */
    #if (DecL__PWM_SEL == DecL_CONFIG)
        #if (0u == DecL_PWM_START_SIGNAL_PRESENT)
            DecL_TriggerCommand(DecL_MASK, DecL_CMD_START);
        #endif /* (0u == DecL_PWM_START_SIGNAL_PRESENT) */
    #endif /* (DecL__PWM_SEL == DecL_CONFIG) */

    #if (DecL__TIMER == DecL_CONFIG)
        #if (0u == DecL_TC_START_SIGNAL_PRESENT)
            DecL_TriggerCommand(DecL_MASK, DecL_CMD_START);
        #endif /* (0u == DecL_TC_START_SIGNAL_PRESENT) */
    #endif /* (DecL__TIMER == DecL_CONFIG) */
    
    #if (DecL__QUAD == DecL_CONFIG)
        #if (0u != DecL_QUAD_AUTO_START)
            DecL_TriggerCommand(DecL_MASK, DecL_CMD_RELOAD);
        #endif /* (0u != DecL_QUAD_AUTO_START) */
    #endif  /* (DecL__QUAD == DecL_CONFIG) */
}


/*******************************************************************************
* Function Name: DecL_Start
********************************************************************************
*
* Summary:
*  Initializes the DecL with default customizer
*  values when called the first time and enables the DecL.
*  For subsequent calls the configuration is left unchanged and the component is
*  just enabled.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DecL_initVar: global variable is used to indicate initial
*  configuration of this component.  The variable is initialized to zero and set
*  to 1 the first time DecL_Start() is called. This allows
*  enabling/disabling a component without re-initialization in all subsequent
*  calls to the DecL_Start() routine.
*
*******************************************************************************/
void DecL_Start(void)
{
    if (0u == DecL_initVar)
    {
        DecL_Init();
        DecL_initVar = 1u;
    }

    DecL_Enable();
}


/*******************************************************************************
* Function Name: DecL_Stop
********************************************************************************
*
* Summary:
*  Disables the DecL.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void DecL_Stop(void)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_BLOCK_CONTROL_REG &= (uint32)~DecL_MASK;

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetMode
********************************************************************************
*
* Summary:
*  Sets the operation mode of the DecL. This function is used when
*  configured as a generic DecL and the actual mode of operation is
*  set at runtime. The mode must be set while the component is disabled.
*
* Parameters:
*  mode: Mode for the DecL to operate in
*   Values:
*   - DecL_MODE_TIMER_COMPARE - Timer / Counter with
*                                                 compare capability
*         - DecL_MODE_TIMER_CAPTURE - Timer / Counter with
*                                                 capture capability
*         - DecL_MODE_QUAD - Quadrature decoder
*         - DecL_MODE_PWM - PWM
*         - DecL_MODE_PWM_DT - PWM with dead time
*         - DecL_MODE_PWM_PR - PWM with pseudo random capability
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetMode(uint32 mode)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_MODE_MASK;
    DecL_CONTROL_REG |= mode;

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetQDMode
********************************************************************************
*
* Summary:
*  Sets the the Quadrature Decoder to one of the 3 supported modes.
*  Its functionality is only applicable to Quadrature Decoder operation.
*
* Parameters:
*  qdMode: Quadrature Decoder mode
*   Values:
*         - DecL_MODE_X1 - Counts on phi 1 rising
*         - DecL_MODE_X2 - Counts on both edges of phi1 (2x faster)
*         - DecL_MODE_X4 - Counts on both edges of phi1 and phi2
*                                        (4x faster)
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetQDMode(uint32 qdMode)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_QUAD_MODE_MASK;
    DecL_CONTROL_REG |= qdMode;

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetPrescaler
********************************************************************************
*
* Summary:
*  Sets the prescaler value that is applied to the clock input.  Not applicable
*  to a PWM with the dead time mode or Quadrature Decoder mode.
*
* Parameters:
*  prescaler: Prescaler divider value
*   Values:
*         - DecL_PRESCALE_DIVBY1    - Divide by 1 (no prescaling)
*         - DecL_PRESCALE_DIVBY2    - Divide by 2
*         - DecL_PRESCALE_DIVBY4    - Divide by 4
*         - DecL_PRESCALE_DIVBY8    - Divide by 8
*         - DecL_PRESCALE_DIVBY16   - Divide by 16
*         - DecL_PRESCALE_DIVBY32   - Divide by 32
*         - DecL_PRESCALE_DIVBY64   - Divide by 64
*         - DecL_PRESCALE_DIVBY128  - Divide by 128
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetPrescaler(uint32 prescaler)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_PRESCALER_MASK;
    DecL_CONTROL_REG |= prescaler;

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetOneShot
********************************************************************************
*
* Summary:
*  Writes the register that controls whether the DecL runs
*  continuously or stops when terminal count is reached.  By default the
*  DecL operates in the continuous mode.
*
* Parameters:
*  oneShotEnable
*   Values:
*     - 0 - Continuous
*     - 1 - Enable One Shot
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetOneShot(uint32 oneShotEnable)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_ONESHOT_MASK;
    DecL_CONTROL_REG |= ((uint32)((oneShotEnable & DecL_1BIT_MASK) <<
                                                               DecL_ONESHOT_SHIFT));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetPWMMode
********************************************************************************
*
* Summary:
*  Writes the control register that determines what mode of operation the PWM
*  output lines are driven in.  There is a setting for what to do on a
*  comparison match (CC_MATCH), on an overflow (OVERFLOW) and on an underflow
*  (UNDERFLOW).  The value for each of the three must be ORed together to form
*  the mode.
*
* Parameters:
*  modeMask: A combination of three mode settings.  Mask must include a value
*  for each of the three or use one of the preconfigured PWM settings.
*   Values:
*     - CC_MATCH_SET        - Set on comparison match
*     - CC_MATCH_CLEAR      - Clear on comparison match
*     - CC_MATCH_INVERT     - Invert on comparison match
*     - CC_MATCH_NO_CHANGE  - No change on comparison match
*     - OVERLOW_SET         - Set on overflow
*     - OVERLOW_CLEAR       - Clear on  overflow
*     - OVERLOW_INVERT      - Invert on overflow
*     - OVERLOW_NO_CHANGE   - No change on overflow
*     - UNDERFLOW_SET       - Set on underflow
*     - UNDERFLOW_CLEAR     - Clear on underflow
*     - UNDERFLOW_INVERT    - Invert on underflow
*     - UNDERFLOW_NO_CHANGE - No change on underflow
*     - PWM_MODE_LEFT       - Setting for left aligned PWM.  Should be combined
*                             with up counting mode
*     - PWM_MODE_RIGHT      - Setting for right aligned PWM.  Should be combined
*                             with down counting mode
*     - PWM_MODE_CENTER     - Setting for center aligned PWM.  Should be
*                             combined with up/down 0 mode
*     - PWM_MODE_ASYM       - Setting for asymmetric PWM.  Should be combined
*                             with up/down 1 mode
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetPWMMode(uint32 modeMask)
{
    DecL_TRIG_CONTROL2_REG = (modeMask & DecL_6BIT_MASK);
}



/*******************************************************************************
* Function Name: DecL_SetPWMSyncKill
********************************************************************************
*
* Summary:
*  Writes the register that controls whether the PWM kill signal (stop input)
*  causes asynchronous or synchronous kill operation.  By default the kill
*  operation is asynchronous.  This functionality is only applicable to the PWM
*  and PWM with dead time modes.
*
*  For Synchronous mode the kill signal disables both the line and line_n
*  signals until the next terminal count.
*
*  For Asynchronous mode the kill signal disables both the line and line_n
*  signals when the kill signal is present.  This mode should only be used
*  when the kill signal (stop input) is configured in the pass through mode
*  (Level sensitive signal).

*
* Parameters:
*  syncKillEnable
*   Values:
*     - 0 - Asynchronous
*     - 1 - Synchronous
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetPWMSyncKill(uint32 syncKillEnable)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_PWM_SYNC_KILL_MASK;
    DecL_CONTROL_REG |= ((uint32)((syncKillEnable & DecL_1BIT_MASK)  <<
                                               DecL_PWM_SYNC_KILL_SHIFT));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetPWMStopOnKill
********************************************************************************
*
* Summary:
*  Writes the register that controls whether the PWM kill signal (stop input)
*  causes the PWM counter to stop.  By default the kill operation does not stop
*  the counter.  This functionality is only applicable to the three PWM modes.
*
*
* Parameters:
*  stopOnKillEnable
*   Values:
*     - 0 - Don't stop
*     - 1 - Stop
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetPWMStopOnKill(uint32 stopOnKillEnable)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_PWM_STOP_KILL_MASK;
    DecL_CONTROL_REG |= ((uint32)((stopOnKillEnable & DecL_1BIT_MASK)  <<
                                                         DecL_PWM_STOP_KILL_SHIFT));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetPWMDeadTime
********************************************************************************
*
* Summary:
*  Writes the dead time control value.  This value delays the rising edge of
*  both the line and line_n signals the designated number of cycles resulting
*  in both signals being inactive for that many cycles.  This functionality is
*  only applicable to the PWM in the dead time mode.

*
* Parameters:
*  Dead time to insert
*   Values: 0 to 255
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetPWMDeadTime(uint32 deadTime)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_PRESCALER_MASK;
    DecL_CONTROL_REG |= ((uint32)((deadTime & DecL_8BIT_MASK) <<
                                                          DecL_PRESCALER_SHIFT));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetPWMInvert
********************************************************************************
*
* Summary:
*  Writes the bits that control whether the line and line_n outputs are
*  inverted from their normal output values.  This functionality is only
*  applicable to the three PWM modes.
*
* Parameters:
*  mask: Mask of outputs to invert.
*   Values:
*         - DecL_INVERT_LINE   - Inverts the line output
*         - DecL_INVERT_LINE_N - Inverts the line_n output
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetPWMInvert(uint32 mask)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_INV_OUT_MASK;
    DecL_CONTROL_REG |= mask;

    CyExitCriticalSection(enableInterrupts);
}



/*******************************************************************************
* Function Name: DecL_WriteCounter
********************************************************************************
*
* Summary:
*  Writes a new 16bit counter value directly into the counter register, thus
*  setting the counter (not the period) to the value written. It is not
*  advised to write to this field when the counter is running.
*
* Parameters:
*  count: value to write
*
* Return:
*  None
*
*******************************************************************************/
void DecL_WriteCounter(uint32 count)
{
    DecL_COUNTER_REG = (count & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_ReadCounter
********************************************************************************
*
* Summary:
*  Reads the current counter value.
*
* Parameters:
*  None
*
* Return:
*  Current counter value
*
*******************************************************************************/
uint32 DecL_ReadCounter(void)
{
    return (DecL_COUNTER_REG & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_SetCounterMode
********************************************************************************
*
* Summary:
*  Sets the counter mode.  Applicable to all modes except Quadrature Decoder
*  and the PWM with a pseudo random output.
*
* Parameters:
*  counterMode: Enumerated counter type values
*   Values:
*     - DecL_COUNT_UP       - Counts up
*     - DecL_COUNT_DOWN     - Counts down
*     - DecL_COUNT_UPDOWN0  - Counts up and down. Terminal count
*                                         generated when counter reaches 0
*     - DecL_COUNT_UPDOWN1  - Counts up and down. Terminal count
*                                         generated both when counter reaches 0
*                                         and period
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetCounterMode(uint32 counterMode)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_UPDOWN_MASK;
    DecL_CONTROL_REG |= counterMode;

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_WritePeriod
********************************************************************************
*
* Summary:
*  Writes the 16 bit period register with the new period value.
*  To cause the counter to count for N cycles this register should be written
*  with N-1 (counts from 0 to period inclusive).
*
* Parameters:
*  period: Period value
*
* Return:
*  None
*
*******************************************************************************/
void DecL_WritePeriod(uint32 period)
{
    DecL_PERIOD_REG = (period & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_ReadPeriod
********************************************************************************
*
* Summary:
*  Reads the 16 bit period register.
*
* Parameters:
*  None
*
* Return:
*  Period value
*
*******************************************************************************/
uint32 DecL_ReadPeriod(void)
{
    return (DecL_PERIOD_REG & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_SetCompareSwap
********************************************************************************
*
* Summary:
*  Writes the register that controls whether the compare registers are
*  swapped. When enabled in the Timer/Counter mode(without capture) the swap
*  occurs at a TC event. In the PWM mode the swap occurs at the next TC event
*  following a hardware switch event.
*
* Parameters:
*  swapEnable
*   Values:
*     - 0 - Disable swap
*     - 1 - Enable swap
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetCompareSwap(uint32 swapEnable)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_RELOAD_CC_MASK;
    DecL_CONTROL_REG |= (swapEnable & DecL_1BIT_MASK);

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_WritePeriodBuf
********************************************************************************
*
* Summary:
*  Writes the 16 bit period buf register with the new period value.
*
* Parameters:
*  periodBuf: Period value
*
* Return:
*  None
*
*******************************************************************************/
void DecL_WritePeriodBuf(uint32 periodBuf)
{
    DecL_PERIOD_BUF_REG = (periodBuf & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_ReadPeriodBuf
********************************************************************************
*
* Summary:
*  Reads the 16 bit period buf register.
*
* Parameters:
*  None
*
* Return:
*  Period value
*
*******************************************************************************/
uint32 DecL_ReadPeriodBuf(void)
{
    return (DecL_PERIOD_BUF_REG & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_SetPeriodSwap
********************************************************************************
*
* Summary:
*  Writes the register that controls whether the period registers are
*  swapped. When enabled in Timer/Counter mode the swap occurs at a TC event.
*  In the PWM mode the swap occurs at the next TC event following a hardware
*  switch event.
*
* Parameters:
*  swapEnable
*   Values:
*     - 0 - Disable swap
*     - 1 - Enable swap
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetPeriodSwap(uint32 swapEnable)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_CONTROL_REG &= (uint32)~DecL_RELOAD_PERIOD_MASK;
    DecL_CONTROL_REG |= ((uint32)((swapEnable & DecL_1BIT_MASK) <<
                                                            DecL_RELOAD_PERIOD_SHIFT));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_WriteCompare
********************************************************************************
*
* Summary:
*  Writes the 16 bit compare register with the new compare value. Not
*  applicable for Timer/Counter with Capture or in Quadrature Decoder modes.
*
* Parameters:
*  compare: Compare value
*
* Return:
*  None
*
* Note:
*  It is not recommended to use the value equal to "0" or equal to 
*  "period value" in Center or Asymmetric align PWM modes on the 
*  PSoC 4100/PSoC 4200 devices.
*  PSoC 4000 devices write the 16 bit compare register with the decremented 
*  compare value in the Up counting mode (except 0x0u), and the incremented 
*  compare value in the Down counting mode (except 0xFFFFu).
*
*******************************************************************************/
void DecL_WriteCompare(uint32 compare)
{
    #if (DecL_CY_TCPWM_4000)
        uint32 currentMode;
    #endif /* (DecL_CY_TCPWM_4000) */

    #if (DecL_CY_TCPWM_4000)
        currentMode = ((DecL_CONTROL_REG & DecL_UPDOWN_MASK) >> DecL_UPDOWN_SHIFT);

        if (((uint32)DecL__COUNT_DOWN == currentMode) && (0xFFFFu != compare))
        {
            compare++;
        }
        else if (((uint32)DecL__COUNT_UP == currentMode) && (0u != compare))
        {
            compare--;
        }
        else
        {
        }
        
    
    #endif /* (DecL_CY_TCPWM_4000) */
    
    DecL_COMP_CAP_REG = (compare & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_ReadCompare
********************************************************************************
*
* Summary:
*  Reads the compare register. Not applicable for Timer/Counter with Capture
*  or in Quadrature Decoder modes.
*  PSoC 4000 devices read the incremented compare register value in the 
*  Up counting mode (except 0xFFFFu), and the decremented value in the 
*  Down counting mode (except 0x0u).
*
* Parameters:
*  None
*
* Return:
*  Compare value
*
* Note:
*  PSoC 4000 devices read the incremented compare register value in the 
*  Up counting mode (except 0xFFFFu), and the decremented value in the 
*  Down counting mode (except 0x0u).
*
*******************************************************************************/
uint32 DecL_ReadCompare(void)
{
    #if (DecL_CY_TCPWM_4000)
        uint32 currentMode;
        uint32 regVal;
    #endif /* (DecL_CY_TCPWM_4000) */

    #if (DecL_CY_TCPWM_4000)
        currentMode = ((DecL_CONTROL_REG & DecL_UPDOWN_MASK) >> DecL_UPDOWN_SHIFT);
        
        regVal = DecL_COMP_CAP_REG;
        
        if (((uint32)DecL__COUNT_DOWN == currentMode) && (0u != regVal))
        {
            regVal--;
        }
        else if (((uint32)DecL__COUNT_UP == currentMode) && (0xFFFFu != regVal))
        {
            regVal++;
        }
        else
        {
        }

        return (regVal & DecL_16BIT_MASK);
    #else
        return (DecL_COMP_CAP_REG & DecL_16BIT_MASK);
    #endif /* (DecL_CY_TCPWM_4000) */
}


/*******************************************************************************
* Function Name: DecL_WriteCompareBuf
********************************************************************************
*
* Summary:
*  Writes the 16 bit compare buffer register with the new compare value. Not
*  applicable for Timer/Counter with Capture or in Quadrature Decoder modes.
*
* Parameters:
*  compareBuf: Compare value
*
* Return:
*  None
*
* Note:
*  It is not recommended to use the value equal to "0" or equal to 
*  "period value" in Center or Asymmetric align PWM modes on the 
*  PSoC 4100/PSoC 4200 devices.
*  PSoC 4000 devices write the 16 bit compare register with the decremented 
*  compare value in the Up counting mode (except 0x0u), and the incremented 
*  compare value in the Down counting mode (except 0xFFFFu).
*
*******************************************************************************/
void DecL_WriteCompareBuf(uint32 compareBuf)
{
    #if (DecL_CY_TCPWM_4000)
        uint32 currentMode;
    #endif /* (DecL_CY_TCPWM_4000) */

    #if (DecL_CY_TCPWM_4000)
        currentMode = ((DecL_CONTROL_REG & DecL_UPDOWN_MASK) >> DecL_UPDOWN_SHIFT);

        if (((uint32)DecL__COUNT_DOWN == currentMode) && (0xFFFFu != compareBuf))
        {
            compareBuf++;
        }
        else if (((uint32)DecL__COUNT_UP == currentMode) && (0u != compareBuf))
        {
            compareBuf --;
        }
        else
        {
        }
    #endif /* (DecL_CY_TCPWM_4000) */
    
    DecL_COMP_CAP_BUF_REG = (compareBuf & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_ReadCompareBuf
********************************************************************************
*
* Summary:
*  Reads the compare buffer register. Not applicable for Timer/Counter with
*  Capture or in Quadrature Decoder modes.
*
* Parameters:
*  None
*
* Return:
*  Compare buffer value
*
* Note:
*  PSoC 4000 devices read the incremented compare register value in the 
*  Up counting mode (except 0xFFFFu), and the decremented value in the 
*  Down counting mode (except 0x0u).
*
*******************************************************************************/
uint32 DecL_ReadCompareBuf(void)
{
    #if (DecL_CY_TCPWM_4000)
        uint32 currentMode;
        uint32 regVal;
    #endif /* (DecL_CY_TCPWM_4000) */

    #if (DecL_CY_TCPWM_4000)
        currentMode = ((DecL_CONTROL_REG & DecL_UPDOWN_MASK) >> DecL_UPDOWN_SHIFT);

        regVal = DecL_COMP_CAP_BUF_REG;
        
        if (((uint32)DecL__COUNT_DOWN == currentMode) && (0u != regVal))
        {
            regVal--;
        }
        else if (((uint32)DecL__COUNT_UP == currentMode) && (0xFFFFu != regVal))
        {
            regVal++;
        }
        else
        {
        }

        return (regVal & DecL_16BIT_MASK);
    #else
        return (DecL_COMP_CAP_BUF_REG & DecL_16BIT_MASK);
    #endif /* (DecL_CY_TCPWM_4000) */
}


/*******************************************************************************
* Function Name: DecL_ReadCapture
********************************************************************************
*
* Summary:
*  Reads the captured counter value. This API is applicable only for
*  Timer/Counter with the capture mode and Quadrature Decoder modes.
*
* Parameters:
*  None
*
* Return:
*  Capture value
*
*******************************************************************************/
uint32 DecL_ReadCapture(void)
{
    return (DecL_COMP_CAP_REG & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_ReadCaptureBuf
********************************************************************************
*
* Summary:
*  Reads the capture buffer register. This API is applicable only for
*  Timer/Counter with the capture mode and Quadrature Decoder modes.
*
* Parameters:
*  None
*
* Return:
*  Capture buffer value
*
*******************************************************************************/
uint32 DecL_ReadCaptureBuf(void)
{
    return (DecL_COMP_CAP_BUF_REG & DecL_16BIT_MASK);
}


/*******************************************************************************
* Function Name: DecL_SetCaptureMode
********************************************************************************
*
* Summary:
*  Sets the capture trigger mode. For PWM mode this is the switch input.
*  This input is not applicable to the Timer/Counter without Capture and
*  Quadrature Decoder modes.
*
* Parameters:
*  triggerMode: Enumerated trigger mode value
*   Values:
*     - DecL_TRIG_LEVEL     - Level
*     - DecL_TRIG_RISING    - Rising edge
*     - DecL_TRIG_FALLING   - Falling edge
*     - DecL_TRIG_BOTH      - Both rising and falling edge
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetCaptureMode(uint32 triggerMode)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_TRIG_CONTROL1_REG &= (uint32)~DecL_CAPTURE_MASK;
    DecL_TRIG_CONTROL1_REG |= triggerMode;

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetReloadMode
********************************************************************************
*
* Summary:
*  Sets the reload trigger mode. For Quadrature Decoder mode this is the index
*  input.
*
* Parameters:
*  triggerMode: Enumerated trigger mode value
*   Values:
*     - DecL_TRIG_LEVEL     - Level
*     - DecL_TRIG_RISING    - Rising edge
*     - DecL_TRIG_FALLING   - Falling edge
*     - DecL_TRIG_BOTH      - Both rising and falling edge
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetReloadMode(uint32 triggerMode)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_TRIG_CONTROL1_REG &= (uint32)~DecL_RELOAD_MASK;
    DecL_TRIG_CONTROL1_REG |= ((uint32)(triggerMode << DecL_RELOAD_SHIFT));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetStartMode
********************************************************************************
*
* Summary:
*  Sets the start trigger mode. For Quadrature Decoder mode this is the
*  phiB input.
*
* Parameters:
*  triggerMode: Enumerated trigger mode value
*   Values:
*     - DecL_TRIG_LEVEL     - Level
*     - DecL_TRIG_RISING    - Rising edge
*     - DecL_TRIG_FALLING   - Falling edge
*     - DecL_TRIG_BOTH      - Both rising and falling edge
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetStartMode(uint32 triggerMode)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_TRIG_CONTROL1_REG &= (uint32)~DecL_START_MASK;
    DecL_TRIG_CONTROL1_REG |= ((uint32)(triggerMode << DecL_START_SHIFT));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetStopMode
********************************************************************************
*
* Summary:
*  Sets the stop trigger mode. For PWM mode this is the kill input.
*
* Parameters:
*  triggerMode: Enumerated trigger mode value
*   Values:
*     - DecL_TRIG_LEVEL     - Level
*     - DecL_TRIG_RISING    - Rising edge
*     - DecL_TRIG_FALLING   - Falling edge
*     - DecL_TRIG_BOTH      - Both rising and falling edge
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetStopMode(uint32 triggerMode)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_TRIG_CONTROL1_REG &= (uint32)~DecL_STOP_MASK;
    DecL_TRIG_CONTROL1_REG |= ((uint32)(triggerMode << DecL_STOP_SHIFT));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_SetCountMode
********************************************************************************
*
* Summary:
*  Sets the count trigger mode. For Quadrature Decoder mode this is the phiA
*  input.
*
* Parameters:
*  triggerMode: Enumerated trigger mode value
*   Values:
*     - DecL_TRIG_LEVEL     - Level
*     - DecL_TRIG_RISING    - Rising edge
*     - DecL_TRIG_FALLING   - Falling edge
*     - DecL_TRIG_BOTH      - Both rising and falling edge
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetCountMode(uint32 triggerMode)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_TRIG_CONTROL1_REG &= (uint32)~DecL_COUNT_MASK;
    DecL_TRIG_CONTROL1_REG |= ((uint32)(triggerMode << DecL_COUNT_SHIFT));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_TriggerCommand
********************************************************************************
*
* Summary:
*  Triggers the designated command to occur on the designated TCPWM instances.
*  The mask can be used to apply this command simultaneously to more than one
*  instance.  This allows multiple TCPWM instances to be synchronized.
*
* Parameters:
*  mask: A combination of mask bits for each instance of the TCPWM that the
*        command should apply to.  This function from one instance can be used
*        to apply the command to any of the instances in the design.
*        The mask value for a specific instance is available with the MASK
*        define.
*  command: Enumerated command values. Capture command only applicable for
*           Timer/Counter with Capture and PWM modes.
*   Values:
*     - DecL_CMD_CAPTURE    - Trigger Capture/Switch command
*     - DecL_CMD_RELOAD     - Trigger Reload/Index command
*     - DecL_CMD_STOP       - Trigger Stop/Kill command
*     - DecL_CMD_START      - Trigger Start/phiB command
*
* Return:
*  None
*
*******************************************************************************/
void DecL_TriggerCommand(uint32 mask, uint32 command)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    DecL_COMMAND_REG = ((uint32)(mask << command));

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DecL_ReadStatus
********************************************************************************
*
* Summary:
*  Reads the status of the DecL.
*
* Parameters:
*  None
*
* Return:
*  Status
*   Values:
*     - DecL_STATUS_DOWN    - Set if counting down
*     - DecL_STATUS_RUNNING - Set if counter is running
*
*******************************************************************************/
uint32 DecL_ReadStatus(void)
{
    return ((DecL_STATUS_REG >> DecL_RUNNING_STATUS_SHIFT) |
            (DecL_STATUS_REG & DecL_STATUS_DOWN));
}


/*******************************************************************************
* Function Name: DecL_SetInterruptMode
********************************************************************************
*
* Summary:
*  Sets the interrupt mask to control which interrupt
*  requests generate the interrupt signal.
*
* Parameters:
*   interruptMask: Mask of bits to be enabled
*   Values:
*     - DecL_INTR_MASK_TC       - Terminal count mask
*     - DecL_INTR_MASK_CC_MATCH - Compare count / capture mask
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetInterruptMode(uint32 interruptMask)
{
    DecL_INTERRUPT_MASK_REG =  interruptMask;
}


/*******************************************************************************
* Function Name: DecL_GetInterruptSourceMasked
********************************************************************************
*
* Summary:
*  Gets the interrupt requests masked by the interrupt mask.
*
* Parameters:
*   None
*
* Return:
*  Masked interrupt source
*   Values:
*     - DecL_INTR_MASK_TC       - Terminal count mask
*     - DecL_INTR_MASK_CC_MATCH - Compare count / capture mask
*
*******************************************************************************/
uint32 DecL_GetInterruptSourceMasked(void)
{
    return (DecL_INTERRUPT_MASKED_REG);
}


/*******************************************************************************
* Function Name: DecL_GetInterruptSource
********************************************************************************
*
* Summary:
*  Gets the interrupt requests (without masking).
*
* Parameters:
*  None
*
* Return:
*  Interrupt request value
*   Values:
*     - DecL_INTR_MASK_TC       - Terminal count mask
*     - DecL_INTR_MASK_CC_MATCH - Compare count / capture mask
*
*******************************************************************************/
uint32 DecL_GetInterruptSource(void)
{
    return (DecL_INTERRUPT_REQ_REG);
}


/*******************************************************************************
* Function Name: DecL_ClearInterrupt
********************************************************************************
*
* Summary:
*  Clears the interrupt request.
*
* Parameters:
*   interruptMask: Mask of interrupts to clear
*   Values:
*     - DecL_INTR_MASK_TC       - Terminal count mask
*     - DecL_INTR_MASK_CC_MATCH - Compare count / capture mask
*
* Return:
*  None
*
*******************************************************************************/
void DecL_ClearInterrupt(uint32 interruptMask)
{
    DecL_INTERRUPT_REQ_REG = interruptMask;
}


/*******************************************************************************
* Function Name: DecL_SetInterrupt
********************************************************************************
*
* Summary:
*  Sets a software interrupt request.
*
* Parameters:
*   interruptMask: Mask of interrupts to set
*   Values:
*     - DecL_INTR_MASK_TC       - Terminal count mask
*     - DecL_INTR_MASK_CC_MATCH - Compare count / capture mask
*
* Return:
*  None
*
*******************************************************************************/
void DecL_SetInterrupt(uint32 interruptMask)
{
    DecL_INTERRUPT_SET_REG = interruptMask;
}


/* [] END OF FILE */
