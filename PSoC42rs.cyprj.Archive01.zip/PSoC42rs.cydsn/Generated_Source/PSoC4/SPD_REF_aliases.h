/*******************************************************************************
* File Name: SPD_REF.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SPD_REF_ALIASES_H) /* Pins SPD_REF_ALIASES_H */
#define CY_PINS_SPD_REF_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define SPD_REF_0			(SPD_REF__0__PC)
#define SPD_REF_0_PS		(SPD_REF__0__PS)
#define SPD_REF_0_PC		(SPD_REF__0__PC)
#define SPD_REF_0_DR		(SPD_REF__0__DR)
#define SPD_REF_0_SHIFT	(SPD_REF__0__SHIFT)
#define SPD_REF_0_INTR	((uint16)((uint16)0x0003u << (SPD_REF__0__SHIFT*2u)))

#define SPD_REF_INTR_ALL	 ((uint16)(SPD_REF_0_INTR))


#endif /* End Pins SPD_REF_ALIASES_H */


/* [] END OF FILE */
